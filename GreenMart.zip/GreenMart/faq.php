<?php

session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");
include("faq_functions.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            background-color: #f8f8f8;
            color: #333;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .faq-container {
            max-width: 600px;
            margin: 0 auto;
        }

        .faq-item {
            background-color: #fff;
            border-radius: 8px;
            margin-bottom: 20px;
            padding: 15px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease-in-out;
        }

        .faq-item:hover {
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }

        .question {
            font-size: 18px;
            font-weight: bold;
            color: #007bff;
        }

        .answer {
            margin-top: 10px;
        }
    </style>
</head>

<body>

    <h1>Frequently Asked Questions</h1>

    <div class="faq-container">
        <div class="faq-item">
            <div class="question">Q: What is Lorem Ipsum?</div>
            <div class="answer">
                A: Lorem Ipsum is simply dummy text of the printing and typesetting industry.
            </div>
        </div>

        <div class="faq-item">
            <div class="question">Q: Why do we use it?</div>
            <div class="answer">
                A: It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
            </div>
        </div>

        <div class="faq-item">
            <div class="question">Q: Where does it come from?</div>
            <div class="answer">
                A: Contrary to popular belief, Lorem Ipsum is not simply random text.
            </div>
        </div>
    </div>

</body>

</html>
