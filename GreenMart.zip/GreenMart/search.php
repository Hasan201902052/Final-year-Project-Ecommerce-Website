<?php
// Database connection
$servername = "localhost"; // Assuming your database is hosted locally
$username = "informed_greenmart";
$password = "green@@mart";
$dbname = "informed_greenmart";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Search query
if (isset($_GET['query'])) {
    $search = $_GET['query'];
    $sql = "SELECT * FROM products WHERE name LIKE '%$search%' OR description LIKE '%$search%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "Product ID: " . $row["id"]. " - Name: " . $row["name"]. " - Description: " . $row["description"]. " - Price: " . $row["price"]. "<br>";
        }
    } else {
        echo "No results found";
    }
}

$conn->close();
?>
