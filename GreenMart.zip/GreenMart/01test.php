<?php

session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif; margin: 0;}

/* Slideshow container */
.slideshow-container {
  position: relative;
  height: 500px; /* Set height to full viewport height */
  overflow: hidden; /* Hide overflow */
}

/* Hide the images by default */
.mySlides {
  display: none;
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background-size: cover; /* Set background size to cover */
}



/* Number text (1/3 etc) and caption */
.numbertext, .text {
  color: #f2f2f2;
  font-size: 15px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
  cursor: pointer; /* Add cursor pointer */
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .9} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 700px) {
  .numbertext, .text {font-size: 11px}
}
</style>
</head>
<body>


<div class="slideshow-container">

<div class="mySlides fade" style="background-image: url('https://t3.ftcdn.net/jpg/04/52/31/22/240_F_452312283_ZIrML8BGm9iRkGjmCjeI4xEgvzIs0G0u.jpg');">
  <div class="numbertext"></div>
  <div class="text">
  <br><br><br>
  <h1 style="color: red; font-size: 60px;" >Welcome To Green Mart</h1>
    <h3 style="color: #fff; font-size: 30px;" >Find Your Desire Product</h3>
    <br><br>
    <a href="shop.php" class="btn1" style="font-size: 20px;  background-color: black;
  width: 120px;
  border: 2px solid red;
  padding: 5px;
  margin: 20px;" >View all Products  </a>
    <br><br><br><br>
  </div>
</div>

<div class="mySlides fade" style="background-image: url('https://t3.ftcdn.net/jpg/06/10/21/84/240_F_610218411_668WmI02oc9sF9mcSGaoo91qL8IF0fyP.jpg');">
  <div class="numbertext"></div>
  <div class="text">
  <br><br><br>
  <h1 style="color: red; font-size: 60px;" >Welcome To Green Mart</h1>
    <h3 style="color: #fff; font-size: 30px;" >Find Your Desire Product</h3>
    <br><br>
    <a href="shop.php" class="btn1" style="font-size: 20px;  background-color: black;
  width: 120px;
  border: 2px solid red;
  padding: 5px;
  margin: 20px;" >View all Products  </a>
    <br><br><br><br>
  </div>
</div>

<div class="mySlides fade" style="background-image: url('https://t3.ftcdn.net/jpg/06/63/92/98/240_F_663929854_s3xHf1LsloQtS2Vv6ediR9X8spyPuUyq.jpg');">
  <div class="numbertext"></div>
  <div class="text">
    <br><br><br>
  <h1 style="color: red; font-size: 60px;" >Welcome To Green Mart</h1>
    <h3 style="color: #fff; font-size: 30px;" >Find Your Desire Product</h3>
    <br><br>
    <a href="shop.php" class="btn1" style="font-size: 20px;  background-color: black;
  width: 120px;
  border: 2px solid red;
  padding: 5px;
  margin: 20px;" >View all Products  </a>
    <br><br><br><br>
  </div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>

<script>
let slideIndex = 0;
showSlides();

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 1500); // Change image every 1 seconds
}
</script>

</body>
</html>
