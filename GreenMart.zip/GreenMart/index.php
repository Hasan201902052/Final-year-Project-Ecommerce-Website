<?php

session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif; margin: 0;}






/* Slideshow container */
.slideshow-container {
  position: relative;
  height: 500px; /* Set height to full viewport height */
  overflow: hidden; /* Hide overflow */
}

/* Hide the images by default */
.mySlides {
  display: none;
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background-size: cover; /* Set background size to cover */
}



/* Number text (1/3 etc) and caption */
.numbertext, .text {
  color: #f2f2f2;
  font-size: 15px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
  cursor: pointer; /* Add cursor pointer */
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .9} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 700px) {
  .numbertext, .text {font-size: 11px}
}
</style>



<div class="slideshow-container">

<div class="mySlides fade" style="background-image: url('https://t3.ftcdn.net/jpg/04/52/31/22/240_F_452312283_ZIrML8BGm9iRkGjmCjeI4xEgvzIs0G0u.jpg');">
  <div class="numbertext"></div>
  <div class="text">
  <br><br><br>
  <h1 style="color: red; font-size: 60px;" >Welcome To Green Mart</h1>
    <h3 style="color: #fff; font-size: 30px;" >Find Your Desire Product</h3>
    <br><br>
    <a href="shop.php" class="btn1" style="font-size: 20px;  background-color: black;
  width: 120px;
  border: 2px solid red;
  padding: 5px;
  margin: 20px;" >View all Products  </a>
    <br><br><br><br>
  </div>
</div>

<div class="mySlides fade" style="background-image: url('https://t3.ftcdn.net/jpg/06/10/21/84/240_F_610218411_668WmI02oc9sF9mcSGaoo91qL8IF0fyP.jpg');">
  <div class="numbertext"></div>
  <div class="text">
  <br><br><br>
  <h1 style="color: red; font-size: 60px;" >Welcome To Green Mart</h1>
    <h3 style="color: #fff; font-size: 30px;" >Find Your Desire Product</h3>
    <br><br>
    <a href="shop.php" class="btn1" style="font-size: 20px;  background-color: black;
  width: 120px;
  border: 2px solid red;
  padding: 5px;
  margin: 20px;" >View all Products  </a>
    <br><br><br><br>
  </div>
</div>

<div class="mySlides fade" style="background-image: url('https://t3.ftcdn.net/jpg/06/63/92/98/240_F_663929854_s3xHf1LsloQtS2Vv6ediR9X8spyPuUyq.jpg');">
  <div class="numbertext"></div>
  <div class="text">
    <br><br><br>
  <h1 style="color: red; font-size: 60px;" >Welcome To Green Mart</h1>
    <h3 style="color: #fff; font-size: 30px;" >Find Your Desire Product</h3>
    <br><br>
    <a href="shop.php" class="btn1" style="font-size: 20px;  background-color: black;
  width: 120px;
  border: 2px solid red;
  padding: 5px;
  margin: 20px;" >View all Products  </a>
    <br><br><br><br>
  </div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>

<script>
let slideIndex = 0;
showSlides();

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 1500); // Change image every 1 seconds
}
</script>



    <div class="wrapper">
            <h2> 
          
            Featured Collection<h2>
            
      </div>
<style> @media only screen and (max-width: 600px) {
  /* Adjust styles for mobile */
  .container {
    width: 100%;
    padding: 0 10px;
  }
} </style>


    <div id="content" class="container"><!-- container Starts -->

    <div class="row"><!-- row Starts -->

    <?php

    getPro();

    ?>






    </div><!-- row Ends -->

    </div><!-- container Ends -->
    <!-- FOOTER -->


    
    <footer class="page-footer">

      <div class="footer-nav">
        <div class="container clearfix">

          <div class="footer-nav__col footer-nav__col--info">
            <div class="footer-nav__heading">Information</div>
            <ul class="footer-nav__list">
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">The brand</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Local stores</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Customer service</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Privacy &amp; cookies</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Site map</a>
              </li>
            </ul>
          </div>

          <div class="footer-nav__col footer-nav__col--whybuy">
            <div class="footer-nav__heading">Why buy from us</div>
            <ul class="footer-nav__list">
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Shipping &amp; returns</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Secure shipping</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Testimonials</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Award winning</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Ethical trading</a>
              </li>
            </ul>
          </div>

          <div class="footer-nav__col footer-nav__col--account">
            <div class="footer-nav__heading">Your account</div>
            <ul class="footer-nav__list">
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Sign in</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Register</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">View cart</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">View your lookbook</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Track an order</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Update information</a>
              </li>
            </ul>
          </div>


          <div class="footer-nav__col footer-nav__col--contacts">
            <div class="footer-nav__heading">Contact details</div>
            <address class="address">
            Head Office: Uttara Dhaka<br>
            Holding No: 984/45, Uttara
          </address>
            <div class="phone">
              Telephone:
              <a class="phone__number" href="tel:0123456789">01628453992</a>
            </div>
            <div class="email">
              Email:
              <a href="mailto:hk1738141@gmail.com" class="email__addr">hk1738141@gmail.com</a>
            </div>
          </div>
 
        </div>
      </div>


      

      <!-- <div class="banners">
        <div class="container clearfix">

          <div class="banner-award">
            <span>Award winner</span><br> Fashion awards 2016
          </div>

          <div class="banner-social">
            <a href="#" class="banner-social__link">
            <i class="icon-facebook"></i>
          </a>
            <a href="#" class="banner-social__link">
            <i class="icon-twitter"></i>
          </a>
            <a href="#" class="banner-social__link">
            <i class="icon-instagram"></i>
          </a>
            <a href="#" class="banner-social__link">
            <i class="icon-pinterest-circled"></i>
          </a>
          </div>

        </div>
      </div> -->

      <div class="page-footer__subline">
        <div class="container clearfix">

          <div class="copyright">
            &copy; <?php echo date("Y");?> HK IT FIRM&trade;
          </div>

          <div class="developer">
          Developed by <a href="https://www.facebook.com/shopnobalok.shopnobalok.50/">Hasan Khan</a>

          </div>

          <div class="designby">
            Design by <a href="https://www.facebook.com/shopnobalok.shopnobalok.50/">Hasan Khan</a>

          </div>

        </div>
      </div>
    </footer>

    
</body>

</html>



 
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Green Mart E-commerce</title>
</head>
<body>

  <!-- Your existing HTML content goes here -->

  <!-- Paste the Messenger Customer Chat Plugin code here -->
  <!-- Begin Facebook Messenger Chat Plugin Code -->
  <div id="fb-root"></div>
  <script>
    window.fbAsyncInit = function() {
      FB.init({
        xfbml            : true,
        version          : 'v13.0'
      });
    };

    (function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
  </script>

  <!-- Your Messenger Customer Chat Plugin Code -->
  <div class="fb-customerchat"
       attribution=setup_tool
       page_id="YourFacebookPageID"
       theme_color="#0084ff">
  </div>
  <!-- End Facebook Messenger Chat Plugin Code -->

</body>
</html>
  


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Green Mart E-commerce</title>
  <style>
    /* Style for buttons container */
    .contact-buttons {
      position: fixed;
      bottom: 20px;
      right: 20px;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    /* Style for individual button */
    .contact-button {
      margin-bottom: 10px;
      padding: 10px;
      background-color: #fff; /* Adjust color as needed */
      color: #fff;
      text-decoration: none;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    /* Style for button icons */
    .contact-button img {
      width: 30px; /* Adjust size as needed */
      height: auto; /* Maintain aspect ratio */
      margin-right: 5px;
    }
  </style>
</head>
<body>

  <!-- Your existing HTML content goes here -->

  <!-- Contact buttons -->
  <div class="contact-buttons">
    <!-- Messenger button -->
    <a href="https://m.me/https://www.facebook.com/RuchirMela" class="contact-button" target="_blank">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWLBD8FYGUEtjVilAhbqULrYhx70vr1s7s-NQ5LIUe_A&s" alt="Messenger Icon"> <!-- Replace with direct image link -->
    </a>

    <!-- WhatsApp button -->
    <a href="https://wa.me/01628453992" class="contact-button" target="_blank">
      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/WhatsApp_icon.png/479px-WhatsApp_icon.png" alt="WhatsApp Icon"> <!-- Replace with direct image link -->
    </a>

    <!-- Direct call button -->
    <a href="tel:+88 01628453992" class="contact-button">
      <img src="https://www.shutterstock.com/image-vector/call-icon-vector-phone-telephone-260nw-1276960162.jpg" alt="Phone Icon"> <!-- Replace with direct image link -->
    </a>
  </div>

</body>
</html>
