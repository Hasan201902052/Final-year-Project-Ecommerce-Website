<?php

function getFAQs($pdo)
{
    $faqs = [];
    try {
        $statement = $pdo->prepare("SELECT * FROM tbl_faq");
        $statement->execute();
        $faqs = $statement->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Handle database error (e.g., log or display an error message)
        echo "Error: " . $e->getMessage();
    }
    return $faqs;
}

?>
