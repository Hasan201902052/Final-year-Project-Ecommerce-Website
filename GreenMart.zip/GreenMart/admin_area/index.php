<?php

session_start();

include("includes/db.php");

if(!isset($_SESSION['admin_email'])){

echo "<script>window.open('login.php','_self')</script>";

}

else {




?>

<?php

$admin_session = $_SESSION['admin_email'];

$get_admin = "select * from admins  where admin_email='$admin_session'";

$run_admin = mysqli_query($con,$get_admin);

$row_admin = mysqli_fetch_array($run_admin);

$admin_id = $row_admin['admin_id'];

$admin_name = $row_admin['admin_name'];

$admin_email = $row_admin['admin_email'];

$admin_image = $row_admin['admin_image'];

$admin_country = $row_admin['admin_country'];

$admin_job = $row_admin['admin_job'];

$admin_contact = $row_admin['admin_contact'];

$admin_about = $row_admin['admin_about'];


$get_products = "SELECT * FROM products";
$run_products = mysqli_query($con,$get_products);
$count_products = mysqli_num_rows($run_products);

$get_customers = "SELECT * FROM customers";
$run_customers = mysqli_query($con,$get_customers);
$count_customers = mysqli_num_rows($run_customers);

$get_p_categories = "SELECT * FROM product_categories";
$run_p_categories = mysqli_query($con,$get_p_categories);
$count_p_categories = mysqli_num_rows($run_p_categories);


$get_total_orders = "SELECT * FROM customer_orders";
$run_total_orders = mysqli_query($con,$get_total_orders);
$count_total_orders = mysqli_num_rows($run_total_orders);


$get_pending_orders = "SELECT * FROM customer_orders WHERE order_status='pending'";
$run_pending_orders = mysqli_query($con,$get_pending_orders);
$count_pending_orders = mysqli_num_rows($run_pending_orders);

$get_completed_orders = "SELECT * FROM customer_orders WHERE order_status='Complete'";
$run_completed_orders = mysqli_query($con,$get_completed_orders);
$count_completed_orders = mysqli_num_rows($run_completed_orders);


$get_total_earnings = "SELECT SUM( due_amount) as Total FROM customer_orders WHERE order_status = 'Complete'";
$run_total_earnings = mysqli_query($con, $get_total_earnings);
$row = mysqli_fetch_assoc($run_total_earnings);                       
$count_total_earnings = $row['Total'];


$get_coupons = "SELECT * FROM coupons";
$run_coupons = mysqli_query($con,$get_coupons);
$count_coupons = mysqli_num_rows($run_coupons);


?>


<!DOCTYPE html>
<html>

<head>

<title>Green Mart Panel</title>

<link href="css/bootstrap.min.css" rel="stylesheet">

<link href="css/style.css" rel="stylesheet">

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" >
<link rel="shortcut icon" href="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIHBhAQBxAQEBASGBARFxYQEhcXEBYVFRUaFyASGBkYHysgGCYlGx8WLT0tJSw3LzA6IyAzRDYuNzQtLisBCgoKDg0OGhAQGi4mHSUvMC0tLy0tLy0tLS8tMistLS0tLS0tLS0tKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABgcBBAUDAv/EADsQAAIBAwIDBQYDBgYDAAAAAAABAgMEEQUGEiExBxMiQWEjMlFxgZFCocEUM1JisfEVFnLC0eEmgrL/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAQIEAwX/xAArEQEAAgICAgEDBAAHAAAAAAAAAQIDEQQhEjEiE0FhBTJRwRQkM3GBkaH/2gAMAwEAAhEDEQA/ALxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADEZKSzHmgMgAAAAAAAAPO4rxtqMp3EowhFNuUmlFJebb5IImYjuUK1PtSsbOo42qrXDXnTilT+82s/RYK+UMl+bjr67alv2t2s6iVe3uYL4rgkl6tcWfsPJWOfjn3Epro2s0Nbte80yrGrHo8cpRfwlF84v5kxLXTJW8brLfJXAAAAAAAAAAAAAAAAHFnfvVNRnb2D9nSeK9WL/ABdf2eDX4se8/wAKwurzE5+XlOodmEVCKUVhLkkui9A6MgAAAAAAAAKS3rrtbd+41ZaVl0YzdOEU8KpOPWrL0WHj4JZKTO508nkZZzZPp19Jzt/s3s9Nt4u/grqtjxSq/u8/CMOmPnlkxWGzHxMdI77lv6jsTT7+i4u1p0n5SoLu5L18PJ/VNE6he3GxWjWkS21sa80HeKlaVsWscSdTl7WDf7mUM9fXouTXPkViupZsPGvjy9T0tIu9AAAYyEbZCQDGQMgYyAyEbZCXzGopNqLTaeH6PGcP6NAfQACG7l3DO81L/DdvTSrvnXr/AIben5v/AFf0yvPpS1mbJlm1vp09/f8ACTaTptPSNOhQso8MILCz7zfVyk/Nt5bZaI071rFY1DbyNwsySBGxjI2OXuWu6GkTdNuMm4JNPD95dPpkyc681wzMe1Mk6q89qSlPTOKtKUm5S5ybbwsLHP5Mr+nzM4dzKMX7e3ZNzoAc/cNy7LQbqrT96nRrzXzjBtfmFMlvGkz+FXdidlGrqtzVkvFSp04R9O8by/tD82Uo87gRE2mVwl3qIdqnaPZ6ZqNWhcRuHOlJwlwQi45XwfEV8oZr8vHS01l42/ahY3FxCFOFzxTlGCzTjjMnhfiHlCsczHM6hCtc3FXt+0atK2nWqQp1GlRVWSpN06fDhrPCo8Sy/Lqysz2y5M1ozzr/AKNJr328NfVOne3OE+KrUoTlTt6UPhCMcZfkm+b+DSbEbn7lJyZb63P9NrWNeu9yaytN2xUqKjDNPjdSXeVODlKtUq+9w5+HX1ykpmZn0nJlvkv9PHPT51Hs1u9Jsp3NldKpVppzkqfHCphLL4Z5zJ/YeMluHkrHlFu0o7M92y1jS60NVmnUtkpOo+XFSafil6rDy/l55JrO2ji55yVny9wi1zq192ha3OjpE5ULWPPCk4RUM446rjzk3/D0+zZXuzNOTLyL+NJ1Dy1vYt3tSyd3p91xd3iU3S4qdSKz73V8S+P9CZiYMnGyYo862SW13dPVezS7r1pcFxSjKhKUPC3KWIxqRx7rfEunmmTvcO9eRN8E2+8IxsqhqO5retQtryrSoJxlUqylOdTLXKlFuWfi2k115+SKxuWfj/VyxMeXX8vLeO0a2zlTubS6nNTnwcazTqxnwuS5qTymlITGkZ8FsPyrZZ+0dblqWzqN1e+/wVON9OJ05Sg5emeHP1JtfxpNpejhyeeOLS4lGtdVbedzpfjuKHNwfu3FKTcnQl6rm4vqm2ujaeDgZr5ImJ+znu0x5V9x/wCpLtncVDcdh3tjLmsKcJfvIS+El+vRnoxO3bFlrkjcI1v3eUrSqrDb+al5Uag3Dn3fF0iv53+XVkTb7Qz8jPr4U/dLUtdH/wAsWtKhlSq1OCvXqdXOfE8Qy+fDHn822+p5fOyzW1aR66lFcf04iPvPtJ90atK1SpWr4ZyWW11S6YXq+Zfn8q2PVKe5aMt9dQ1LfbNSpSU6tbgqPnjDbT9ZZ6nKnAyTXym8xKsYp13Lm6jdXEKypXFSSnT8OYya4s803jr5GXNlzxfwtPcKWtbepbGr3dSnrjjbzm+F04xipPDaS5Y88svyMuSM+qzPWk3tPl037fb1ad1CreVU5cSlJZeeXPCZqpwss3i97Lxjne5lpbltatCs516mYTk+GKlJ4S9HyXIzc7FkrM2tPUz6VyxMdt7bemVac6dWdT2TTkoKUvxL4dDTwePkrq8z8delsdZjtJj1XYA1tTtFf6dWoz6VYVKb+U4uP6hW8eVZhS/Zrq621uepR1T2cauaE3LkoVYS5cT8lniX1Xkc69PK4t/pZJrZeGco6PXRTVtl6Xmtc6nRSy51ak5V6yWW3Jy5TwufwImIZr8bD3a0Ks2lp8da33TWnU3C3jVddRy3wUacuJKTbb5+BfNlI9vOw0i+b4+nZ7N8al2iXFZ801d1vTx1Ev6SYr7deL8s9p/3W1dUVa6bVVlCMHw1GlCKXi4Xz5HR6do1E6URsLQ6mu386dhdytKkafFmHFxSjxJNeGSeE+H8jlWNvG42Oclp1bUptU7PL1QbqazW4cPOXVxj19qW8ZbP8Lk1+95/5JntXbep1P2hVu8t5wxGm4YXVv3nnlka1CI4/wBLHad73CM7C23W16nXenX07SVN01KMOPMk08SfDNefERETLNxsU5InxtpKK/ZxeTpONxrFRwl4Wp964vPLhadXDyT4tM8S/wB7tDcW23s/YtzSq11WdzWtksQcccGZ4w28+6RMTEKZcX0cMxv3KV9ktqqGzacksOrOtUfrifBn7RRevpo4UaxQ5nbZX4dEtqf8VZz+kKcl/uRW/pz58/CI/LZ0t/sHZzZU48nVhGX0m3Vb/NfcxfqGTxw6/l0p8cNYSTatt3GkqT61G5/TovyRb9Px+OGJ/l3xxqqvu0LR622NV/xLb85UYVcxqcHSE5+bT5cMn8ekvVrGuY12w8nHbHb6lP8Al1+y/aTsaP7dqibuKqbgp85QhLm5vP4pfdL5smsOnEwePzt7l0d5ctRg/wCRf/Ujxf1L/VrP4/t2y/uh8axL/wAnTqe7xUOvTh8L/wCSnJn/ADUb/CL/AL008j32lDdTaut0xjDmlOlF/TGf1PCz6ycuIj+YZ7d3NNX7VuqUnzSnVl9spfoMHz5kz+ZRXvImZ7rSie9antaMfgpy+7S/Rnjfqlu61cM0+klsafc2VOP8MYL7JHq4o1SI/DtHp7nRIAAgu++z+Ov1ncabKNK5xiSl+7q4WFxY5xfTn/dVmu2PkcWMnce0PtrbX9Ah3Vorju48ko93Whj+XPFwr05Eds0V5NOoK2ga3umpGOq94qfX28oU6S9e7hzb/wDUj5SicXIy9WWHtnasNraPUjZe1uZxblN4TnJJ4gsvEVn1+peI03YsEYq6j2j3ZXtW60G9uKmr0e64oU4Q8cJZ8Tb9xvHSJWsTDjxMF8czNoWQXblSbg2NeaJrTu9pZceJyjGm4qpSz1hwy5Tj/bHLJSa99PNycbJS/niat9T17c8O4u6VSFJ4Uk4xo036zfWS9Fn5D5SraOTl6mNQsvb2hvTNuxtL+rK58Moyc+axLk6cc8+FLks/9K0N+PH408Z7VtdbP1LaWrutthzq03lJw4XPgbz3dSEve+az0zyZXUx6YJ4+XFbeP0+LrTdb3fVjT1OM6VJNP2iVKlFr8TivFN/Dr9BqZ9k05GWdW6hJd+bau77blna6dx3cqUuKc6k4Rm3GDipNyaz7z+P/ADMx078jDe2OK17SraNhLS9tWtG4jw1IU4qSynib5tZXJ82+hMemnDWa0iJRPtU29ea/XtlpNHvY0o1uL2lOPim44Xjks8okWiZZuXhvk14unfaJXnRtqVvT9nRpUqSfFHGVFJvGfRfY8zm8fLlvHjHUO0451EQllCkqNGMIdIpRXySwenSvjWIh2iNdFehG4pOFeMZxfVSScX80yxMbegSjW59Lq313GVrDiSjh+KK55b82eVzuNky3iaQ45KTaemdwaLO8Uatsk5qKjKOVzx5p9CeZw7ZNXr70ZMcz3DUt5ahKmqUFNLpxTSTS/wBT/ucaTzJjw0rH1PTOl6JWttXjOtHMIuT4uKPPk8PGc83gYOHlpmi1vUJrjmLbls7b0qraX8ql5DhzFpeJPm2n5M7cLjZKZJveE46TE7lJT1HZGdwaXWv9TjKlDNNRjHPFFfibfJvPmeXzONky5YmI6cb0mbQkq6HqQ7MgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/Z" type="image/png">

</head>

<body>

<div id="wrapper"><!-- wrapper Starts -->

<?php include("includes/sidebar.php");  ?>

<div id="page-wrapper"><!-- page-wrapper Starts -->

<div class="container-fluid"><!-- container-fluid Starts -->

<?php

if(isset($_GET['dashboard'])){

include("dashboard.php");

}

if(isset($_GET['insert_product'])){

include("insert_product.php");

}

if(isset($_GET['view_products'])){

include("view_products.php");

}

if(isset($_GET['delete_product'])){

include("delete_product.php");

}

if(isset($_GET['edit_product'])){

include("edit_product.php");

}

if(isset($_GET['insert_p_cat'])){

include("insert_p_cat.php");

}

if(isset($_GET['view_p_cats'])){

include("view_p_cats.php");

}

if(isset($_GET['delete_p_cat'])){

include("delete_p_cat.php");

}

if(isset($_GET['edit_p_cat'])){

include("edit_p_cat.php");

}

if(isset($_GET['insert_cat'])){

include("insert_cat.php");

}

if(isset($_GET['view_cats'])){

include("view_cats.php");

}

if(isset($_GET['delete_cat'])){

include("delete_cat.php");

}

if(isset($_GET['edit_cat'])){

include("edit_cat.php");

}

if(isset($_GET['insert_slide'])){

include("insert_slide.php");

}


if(isset($_GET['view_slides'])){

include("view_slides.php");

}

if(isset($_GET['delete_slide'])){

include("delete_slide.php");

}


if(isset($_GET['edit_slide'])){

include("edit_slide.php");

}


if(isset($_GET['view_customers'])){

include("view_customers.php");

}

if(isset($_GET['customer_delete'])){

include("customer_delete.php");

}


if(isset($_GET['view_orders'])){

include("view_orders.php");

}

if(isset($_GET['order_delete'])){

include("order_delete.php");

}


if(isset($_GET['view_payments'])){

include("view_payments.php");

}

if(isset($_GET['payment_delete'])){

include("payment_delete.php");

}

if(isset($_GET['insert_user'])){

include("insert_user.php");

}

if(isset($_GET['view_users'])){

include("view_users.php");

}


if(isset($_GET['user_delete'])){

include("user_delete.php");

}



if(isset($_GET['user_profile'])){

include("user_profile.php");

}

if(isset($_GET['insert_box'])){

include("insert_box.php");

}

if(isset($_GET['view_boxes'])){

include("view_boxes.php");

}

if(isset($_GET['delete_box'])){

include("delete_box.php");

}

if(isset($_GET['edit_box'])){

include("edit_box.php");

}

if(isset($_GET['insert_term'])){

include("insert_term.php");

}

if(isset($_GET['view_terms'])){

include("view_terms.php");

}

if(isset($_GET['delete_term'])){

include("delete_term.php");

}

if(isset($_GET['edit_term'])){

include("edit_term.php");

}

if(isset($_GET['edit_css'])){

include("edit_css.php");

}

if(isset($_GET['insert_manufacturer'])){

include("insert_manufacturer.php");

}

if(isset($_GET['view_manufacturers'])){

include("view_manufacturers.php");

}

if(isset($_GET['delete_manufacturer'])){

include("delete_manufacturer.php");

}

if(isset($_GET['edit_manufacturer'])){

include("edit_manufacturer.php");

}


if(isset($_GET['insert_coupon'])){

include("insert_coupon.php");

}

if(isset($_GET['view_coupons'])){

include("view_coupons.php");

}

if(isset($_GET['delete_coupon'])){

include("delete_coupon.php");

}


if(isset($_GET['edit_coupon'])){

include("edit_coupon.php");

}


if(isset($_GET['insert_icon'])){

include("insert_icon.php");

}


if(isset($_GET['view_icons'])){

include("view_icons.php");

}

if(isset($_GET['delete_icon'])){

include("delete_icon.php");

}

if(isset($_GET['edit_icon'])){

include("edit_icon.php");

}

if(isset($_GET['insert_bundle'])){

include("insert_bundle.php");

}

if(isset($_GET['view_bundles'])){

include("view_bundles.php");

}

if(isset($_GET['delete_bundle'])){

include("delete_bundle.php");

}


if(isset($_GET['edit_bundle'])){

include("edit_bundle.php");

}


if(isset($_GET['insert_rel'])){

include("insert_rel.php");

}

if(isset($_GET['view_rel'])){

include("view_rel.php");

}

if(isset($_GET['delete_rel'])){

include("delete_rel.php");

}


if(isset($_GET['edit_rel'])){

include("edit_rel.php");

}


if(isset($_GET['edit_contact_us'])){

include("edit_contact_us.php");

}

if(isset($_GET['insert_enquiry'])){

include("insert_enquiry.php");

}


if(isset($_GET['view_enquiry'])){

include("view_enquiry.php");

}

if(isset($_GET['delete_enquiry'])){

include("delete_enquiry.php");

}

if(isset($_GET['edit_enquiry'])){

include("edit_enquiry.php");

}


if(isset($_GET['edit_about_us'])){

include("edit_about_us.php");

}


if(isset($_GET['insert_store'])){

include("insert_store.php");

}

if(isset($_GET['view_store'])){

include("view_store.php");

}

if(isset($_GET['delete_store'])){

include("delete_store.php");

}

if(isset($_GET['edit_store'])){

include("edit_store.php");

}

?>

</div><!-- container-fluid Ends -->

</div><!-- page-wrapper Ends -->

</div><!-- wrapper Ends -->

<script src="js/jquery.min.js"></script>

<script src="js/bootstrap.min.js"></script>


</body>


</html>

<?php } ?>