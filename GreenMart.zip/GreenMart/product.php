<?php
session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

// Retrieve category ID from the URL
$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : 0;

// Fetch products based on the category ID
$query = "SELECT * FROM products";
if ($category_id > 0) {
    $query .= " WHERE category_id = $category_id";
}
$result = mysqli_query($con, $query);

if ($result) {
    echo "<div id='products_container'>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='product'>";
        echo "<h3>" . $row['product_name'] . "</h3>";
        echo "<p>Price: $" . $row['price'] . "</p>";
        // Add more product details as needed

        echo "</div>";
    }
    echo "</div>";
} else {
    echo "Error fetching products: " . mysqli_error($con);
}

include("includes/footer.php");
?>
