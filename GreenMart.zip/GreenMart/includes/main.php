</head>

<body>

<style>  
/* Responsive styles */
@media only screen and (max-width: 600px) {
  /* Adjust styles for mobile */
  .container {
    width: 100%;
    padding: 0 10px;
  }
}
</style>

  <header class="page-header">
    <!-- topline -->
    <div class="page-header__topline">
      <div class="container clearfix">

        <div class="currency">
          <a class="currency__change" href="customer/my_account.php?my_orders">
          <?php
          if(!isset($_SESSION['customer_email'])){
          echo "Welcome To Green Mart"; 
          }
          else
          { 
              echo "Welcome : " . $_SESSION['customer_email'] . "";
            }
?>
          </a>
        </div>

        <div class="basket">
          <a href="cart.php" class="btn btn--basket">
            <i class="icon-basket"></i>
            <?php items(); ?> items
          </a>
        </div>
        
        
        <ul class="login">

<li class="login__item">
<?php
if(!isset($_SESSION['customer_email'])){
  echo '<a href="customer_register.php" class="login__link">Register</a>';
} 
  else
  { 
      echo '<a href="customer/my_account.php?my_orders" class="login__link">My Account</a>';
  }   
?>  
</li>


<li class="login__item">
<?php
if(!isset($_SESSION['customer_email'])){
  echo '<a href="checkout.php" class="login__link">Sign In</a>';
} 
  else
  { 
      echo '<a href="./logout.php" class="login__link">Logout</a>';
  }   
?>  
  
</li>
</ul>
      
      </div>
    </div>
    <!-- bottomline -->
    <div class="page-header__bottomline">
      <div class="container clearfix">

        <!-- Include jQuery library -->
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<style>
  /* Add CSS styles for the search box */
  .search-box {
    display: inline-block;
    margin-top: 40px;
    margin-left: 30px; /* Adjust the margin as needed */
  }

  .search-box input[type="text"] {
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }

  .search-box button {
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    background-color: #f5f5f5;
    cursor: pointer;
  }
</style>

<script>
  $(document).ready(function() {
    // Listen for changes in the search input field
    $('#search-input').on('input', function() {
      // Get the search value
      var searchValue = $(this).val().toLowerCase();

    // Perform an AJAX request to a server-side script for searching
    $.ajax({
          url: 'search.php', // Replace with the actual path to your server-side script
          method: 'POST',
          data: { searchValue: searchValue },
          dataType: 'json',
          success: function(response) {
            // Handle the search results here
            console.log('Search Results:', response);
            // Update the UI with the search results
            // You can replace this part with your specific logic to display search results
          },
          error: function(error) {
            console.error('Search Error:', error);
          }
        });
      });
    });
  </script>
</head>

<body>

<header class="page-header">
  <!-- Your existing header content here -->

  <div class="container clearfix">
    <div class="logo">
      <a class="logo__link" href="index.php">
        <img class="logo__img" src="images/logo.png" alt="Green Mart" logotype width="237" height="19">
      </a>
    </div>

    <!-- Search box -->
    <div class="search-box">


      <form action="search.php" method="GET">
        <input type="text" name="query" placeholder="Search...">
        <button type="submit">Search</button>
    </form>
     
    </div>
        

        <nav class="main-nav">
          <ul class="categories">

            <li class="categories__item">
              <a class="categories__link" href="index.php">
                Home
               
              </a>
              </li>


              <li class="categories__item">
              <a class="categories__link" href="about.php">
                About us
              </a>
            </li>

             

            <li class="categories__item">
              <a class="categories__link categories__link--active" href="shop.php">
                Shop
              </a>
            </li>

            <li class="categories__item">
              <a class="categories__link" href="contact.php">
                Contact Us
               
              </a>
            </li>

           

          <li class="categories__item">
              <a class="categories__link" href="customer/my_account.php?my_orders">
                My Account
                <i class="icon-down-open-1"></i>
              </a>
              <div class="dropdown dropdown--lookbook">
                <div class="clearfix">
                  <div class="dropdown__half">
                    <div class="dropdown__heading">Account Settings</div>
                    <ul class="dropdown__items">
                      <li class="dropdown__item">
                        <a href="customer/my_account.php?my_wishlist" class="dropdown__link">My Wishlist</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="customer/my_account.php?my_orders" class="dropdown__link">My Orders</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="cart.php" class="dropdown__link">View Shopping Cart</a>
                      </li>
                    </ul>
                  </div>
                  <div class="dropdown__half">
                    <div class="dropdown__heading"></div>
                    <ul class="dropdown__items">
                      <li class="dropdown__item">
                        <a href="customer/my_account.php?edit_account" class="dropdown__link">Edit Your Account</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="customer/my_account.php?change_pass" class="dropdown__link">Change Password</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="customer/my_account.php?delete_account" class="dropdown__link">Delete Account</a>
                      </li>
                    </ul>
                  </div>
                </div>
             

              </div>

            </li>

          </ul>
        </nav>
      </div>
    </div>
  </header>